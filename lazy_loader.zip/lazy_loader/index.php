<style>
    /* * {
        background: #000;
    } */

    img {
        width: 400px;
        height: 300px;
        float: left;
        margin: 0 10px 10px 0
    }

    .loader {
        width: 100%;
        height: 100%;
        position: absolute;
        top: 0;
        left: 0;
        background: #fff url(https://upload.wikimedia.org/wikipedia/commons/b/b1/Loading_icon.gif) no-repeat center center;
    }
</style>
<?php
$str = "Hey @there#! How ( are) you *d_oing/?";
echo preg_replace("/[a-zA-Z0-9]/", "", $str);
// echo $res;die;
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.lazyload/1.9.1/jquery.lazyload.js"></script>

<div class="loader"></div>

<div class="images">

<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-2.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-2.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-3.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-3.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-4.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-4.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-5.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-5.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-6.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-6.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-7.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-7.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-8.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-8.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-9.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-9.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-10.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-10.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-2.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-2.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-3.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-3.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-4.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-4.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-5.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-5.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-6.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-6.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-7.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-7.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-8.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-8.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-9.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-9.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-10.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-10.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-2.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-2.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-3.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-3.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-4.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-4.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-5.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-5.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-6.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-6.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-7.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-7.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-8.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-8.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-9.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-9.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-10.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-10.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-2.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-2.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-3.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-3.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-4.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-4.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-5.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-5.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-6.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-6.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-7.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-7.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-8.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-8.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-9.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-9.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-10.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-10.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-2.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-2.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-3.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-3.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-4.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-4.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-5.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-5.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-6.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-6.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-7.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-7.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-8.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-8.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-9.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-9.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-10.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-10.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-2.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-2.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-3.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-3.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-4.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-4.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-5.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-5.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-6.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-6.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-7.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-7.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-8.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-8.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-9.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-9.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-10.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-10.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-2.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-2.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-3.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-3.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-4.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-4.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-5.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-5.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-6.jpg"  data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-6.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-7.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-7.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-8.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-8.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-9.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-9.jpg">
<img class="lazy" src="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-10.jpg" data-original="http://www.hotelgarcinialeaf.com/images/gallery/thumbs/img-10.jpg">

</div>

<script>
    $(document).ready(function() {
        $('.loader').hide();
    });

    $("img.lazy").lazyload({
        effect: "slideDown"
    });
</script>